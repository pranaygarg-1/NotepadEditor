# NotepadEditor
This is the simple notepad clone that I have made by using OOPS concepts and Java Programming Language.
